<!DOCTYPE html>
<html>
<head>
	<title>Globour</title>
	<link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body>
	<div class = "goHome_Login">
		<a href="index.php">Learn More</a>
	</div>
	<h1 class = "loginHeader">Please Log In or Register</h1>
	<div class = "loginAndRegister">
		<a href="login.php" class = "loginAndRegister_Link">Login</a> or
		<a href="register.php" class = "loginAndRegister_Link">Register</a>
	</div>
	
</body>
</html>